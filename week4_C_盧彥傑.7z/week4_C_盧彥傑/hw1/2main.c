#include <stdio.h>
#define MAX_NODES 100


int matrix[MAX_NODES][MAX_NODES];
int positions[MAX_NODES * MAX_NODES][2]; // �ΨӰO���Ҧ��Ȭ� 1 ����m
int visited[MAX_NODES];
int row;
int column;
int numPositions = 0; // �O������m�ƶq

int main() {
    FILE *file;
    char filename[100] = "1.txt";
    int i, j,k;
    int l,m, n;
    int o, count;
    count = 0;
    
    int test = 0;

//    printf("�п�J�ɮצW�١G");
//    scanf("%s", filename);

    // ���}�ɮ�
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("�L�k���}�ɮסC\n");
        return 1;
    }

    // �q�ɮפ�Ū���`�I�ƥةM�F���x�}���ܪ���
    fscanf(file, "%d", &row);
    fscanf(file, "%d", &column);
    for (i = 0; i < row; i++) {
        for (j = 0; j < column; j++) {
            fscanf(file, "%d", &matrix[i][j]);
            if (matrix[i][j] == 1) {
                positions[numPositions][0] = i;  //R�� 
                positions[numPositions][1] = j;  //C�� 
                numPositions++;
            }
        }
    }

    

    // �����ɮ�
    fclose(file);
    
    for( i = 0 ; i < numPositions ; i++){
    	for ( j = i+1; j < numPositions ; j++){
    		if (positions[i][1] == positions[j][1] ){
//    			printf("(%d, %d)(%d,%d)\n", positions[i][0], positions[i][1],positions[j][0], positions[j][1]);  //test
    			for( k=j+1; k < numPositions; k++){
    				if(positions[j][0] == positions[k][0] ){
//    					printf("(%d, %d)(%d,%d)\n", positions[j][0], positions[j][1],positions[k][0], positions[k][1]); //test
    					for( l=k+1; l<numPositions; l++ ){
    						if(positions[k][1] == positions[l][1] ){
//    							printf("(%d, %d)(%d,%d)\n", positions[k][0], positions[k][1],positions[l][0], positions[l][1]); //test
    							for( m=l-1; m>=0;m--  ){
    								if(positions[l][0] == positions[m][0] ){
//    									printf("(%d, %d)(%d,%d)\n", positions[l][0], positions[l][1],positions[m][0], positions[m][1]); //test
    									for(n=m-1; n>=0; n--){
    										if(positions[m][1] == positions[n][1] && positions[n][0] == positions[i][0]){
//    										    printf("(%d, %d)(%d,%d)\n stop\n", positions[m][0], positions[m][1],positions[n][0], positions[n][1]); //test	
    											
    											printf("(%d,%d)(%d,%d)(%d,%d)(%d,%d)(%d,%d)(%d,%d)\n", positions[i][0], positions[i][1],positions[j][0], positions[j][1],
												positions[k][0], positions[k][1],positions[l][0], positions[l][1],positions[m][0], positions[m][1],positions[n][0], positions[n][1]);
    											count++;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			 
		 
    	
	
    
    
    printf("6cycle�@��%d��\n", count);

//    int totalCycles = count_cycles();
//    printf("�Ϥ��s�b %d �Ӵ`���C\n", totalCycles);

    // ��X�Ҧ��Ȭ� 1 ����m
    
//    printf("�Ȭ� 1 ����m�G\n");
//    for (i = 0; i < numPositions; i++) {
//        printf("(%d, %d)\n", positions[i][0], positions[i][1]);  //(R,C)
//    }

    return 0;
}
