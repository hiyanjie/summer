#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ROWS 48
#define COLUMNS 96
#define COLUMN_WEIGHT 3
#define ROW_WEIGHT 6

int isFullRank(int matrix[ROWS][COLUMNS]) {
    int i, j, k;

    for (i = 0; i < ROWS; i++) {
        for (j = i + 1; j < ROWS; j++) {
            // Find the factor to eliminate the leading coefficient in row j
            double factor = (double)matrix[j][i] / matrix[i][i];

            for (k = i; k < COLUMNS; k++) {
                matrix[j][k] -= factor * matrix[i][k];
            }
        }
    }

    // Check if there are any all-zero rows
    for (i = 0; i < ROWS; i++) {
        int isZeroRow = 1;
        for (j = 0; j < COLUMNS; j++) {
            if (matrix[i][j] != 0) {
                isZeroRow = 0;
                break;
            }
        }
        if (isZeroRow) {
            return 0;  // Matrix is not full rank
        }
    }
    return 1;  // Matrix is full rank
}
 
void print_matrix(int matrix[ROWS][COLUMNS]) {
	int i, j;
    for ( i = 0; i < ROWS; i++) {
        for ( j = 0; j < COLUMNS; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main() {
    srand(time(NULL));
    int matrix[ROWS][COLUMNS] = {0};
    int row_indices[ROWS][ROW_WEIGHT];  // �s�x�C�檺�C����
    int i, j;
    int a = 0;

    for ( i = 0; i < ROWS; i++) {
        for ( j = 0; j < ROW_WEIGHT; j++) {
            int col;
            do {
                col = rand() % COLUMNS;
            } while (matrix[i][col] == 1);
            matrix[i][col] = 1;
            row_indices[i][j] = col;  // �s�x�����
            
    }     
        }
 //test
    
    // �p��C�@�C�X�{ 1 �����ƨÿ�X
    int column_counts[COLUMNS] = {0};
    for ( i = 0; i < COLUMNS; i++) {
        for ( j = 0; j < ROWS; j++) {
            if (matrix[j][i] == 1) {
                column_counts[i]++;
            }
        }
    }
 
    int row_counts[ROWS] = {0};
    for ( i = 0; i < ROWS; i++) {
        for ( j = 0; j < COLUMNS; j++) {
            if (matrix[i][j] == 1) {
                row_counts[i]++;
            }
        }
    }

//test
    	
	for ( i = 0; i < 96; i++) {
    while (column_counts[i] > 3) {
        int row = -1;
        int targetCol = -1;

        // Find a row with value 1 in the current column
        for ( j = 0; j < 48; j++) {
            if (matrix[j][i] == 1) {
                row = j;
                break;
            }
        }

        // Find a column with value 0 in the same row
        for ( j = 0; j < 96; j++) {
            if (matrix[row][j] == 0 && column_counts[j] < 3) {
                targetCol = j;
                break;
            }
        }

        // If suitable row and column are found, perform the swap
        if (row != -1 && targetCol != -1) {
            matrix[row][i] = 0;
            matrix[row][targetCol] = 1;
            column_counts[i]--;
            column_counts[targetCol]++;
        } else {
            // If no suitable swap is possible, break the loop
            break;
        }
    }
}
   
//test
    print_matrix(matrix);
    
    int col_counts[COLUMNS] = {0};
    for ( i = 0; i < COLUMNS; i++) {
        for ( j = 0; j < ROWS; j++) {
            if (matrix[j][i] == 1) {
                col_counts[i]++;
            }
        }
    }

    printf("\nColumn counts:\n"); 
    for ( i = 0; i < COLUMNS; i++) {
        printf("Column %d: %d\n", i, col_counts[i]);
    }
    
    int ro_counts[ROWS] = {0};
    for ( i = 0; i < ROWS; i++) {
        for ( j = 0; j < COLUMNS; j++) {
            if (matrix[i][j] == 1) {
                ro_counts[i]++;
            }
        }
    }

    printf("\nRow counts:\n");
    for ( i = 0; i < ROWS; i++) {
        printf("Row %d: %d\n", i, ro_counts[i]);
    }  
//test
    
    
    
    if (isFullRank(matrix)) {
        printf("The matrix is full rank.\n");
    } else {
        printf("The matrix is not full rank.\n");
    }
    
    
    return 0;
}



